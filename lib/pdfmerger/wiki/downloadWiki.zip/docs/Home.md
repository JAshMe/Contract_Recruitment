**Project Description**
PDF Merger for PHP makes it incredibly easy to merge multiple PDFs together in your PHP web application. After merging you can either output to the browser, prompt a download, save it to a file location or return it as a string.

**How to Use**
Unpack PDFMerger.zip after downloading and upload it to your web server. Include the following file in your PHP code, "PDFMerger.php". Then its as simple as..
{code:php}
<?php
include 'PDFMerger.php';

$pdf = new PDFMerger;

$pdf->addPDF('samplepdfs/one.pdf', '1, 3, 4')
	->addPDF('samplepdfs/two.pdf', '1-2')
	->addPDF('samplepdfs/three.pdf', 'all')
	->merge('file', 'samplepdfs/TEST2.pdf');
	
	//REPLACE 'file' WITH 'browser', 'download', 'string', or 'file' for output options
	//You do not need to give a file path for browser, string, or download - just the name.
?>
{code:php}


Please post any problems you run across!